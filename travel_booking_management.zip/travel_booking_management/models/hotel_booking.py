# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class HotelBooking(models.Model):
    _name = 'travel.hotel.booking'
    _description = 'Hotel Booking'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'travel.sale.purchase.mixin']
    _order = 'create_date desc'

    name = fields.Char(string='Booking Reference', required=True, copy=False,
                       readonly=True, default=lambda self: _('New'))
    booking_date = fields.Date(string='Booking Date', default=fields.Date.context_today, tracking=True)
    booking_executive = fields.Selection([
        ('krupali_gosrani', 'KRUPALI GOSRANI'),
        ('deba_behera', 'DEBA BEHERA'),
        ('tejas_mahyavanshi', 'TEJAS MAHYAVANSHI'),
        ('rahul_patel', 'RAHUL PATEL'),
        ('sapna_kushwaha', 'SAPNA KUSHWAHA'),
        ('jatin_pardikar', 'JATIN PARDIKAR'),
        ('mitesh_patel_domestic', 'MITESH PATEL DOMESTIC'),
        ('mitesh_bhanushali', 'MITESH BHANUSHALI'),
        ('debashish_jena', 'DEBASHISH JENA'),
        ('ronak_patel', 'RONAK PATEL'),
        ('nikhil_gaikwad', 'NIKHIL GAIKWAD'),
        ('parth_patel', 'PARTH PATEL'),
        ('zeel_shah', 'ZEEL SHAH'),
        ('saloni_shah', 'SALONI SHAH'),
        ('shruti_rohit', 'SHRUTI ROHIT'),
        ('naazu_kajani', 'NAAZU KAJANI'),
        ('nikheel_jain', 'NIKHEEL JAIN'),
        ('anjali_vaishanav', 'ANJALI VAISHANAV'),
        ('divya_patel_hotel', 'DIVYA PATEL(HOTEL)'),
        ('milan_patel', 'MILAN PATEL'),
        ('anuj_mhatre', 'ANUJ MHATRE'),
        ('nadim_shaikh', 'NADIM SHAIKH'),
        ('sagrika_patel', 'SAGRIKA PATEL'),
        ('disha_pandorwala', 'DISHA PANDORWALA'),
        ('vani_agrawal', 'VANI AGRAWAL'),
        ('hiten_patel', 'HITEN PATEL'),
        ('viren_patel', 'VIREN PATEL'),
        ('riya_patel', 'RIYA PATEL'),
        ('amit_rout', 'AMIT ROUT'),
        ('mitali_patel', 'MITALI PATEL'),
        ('riya_panwala', 'RIYA PANWALA'),
        ('gunvanti_patel', 'GUNVANTI PATEL'),
        ('muskan_mehrotra', 'MUSKAN MEHROTRA'),
        ('sweety_sikdar', 'SWEETY SIKDAR'),
        ('avisha_patel', 'AVISHA PATEL'),
        ('shruti_jaiswal', 'SHRUTI JAISWAL'),
        ('sumi_kalita', 'SUMI KALITA'),
        ('reshma_sarkar', 'RESHMA SARKAR'),
        ('snehangi_sagar', 'SNEHANGI SAGAR'),
        ('saurabh_singh', 'SAURABH SINGH'),
        ('jaya_yadav', 'JAYA YADAV'),
        ('mitali_shah', 'MITALI SHAH'),
        ('adarsh_singh', 'ADARSH SINGH'),
        ('dhruvi_patel', 'DHRUVI PATEL'),
        ('anand_halpati', 'ANAND HALPATI'),
        ('aditya_singh', 'ADITYA SINGH'),
        ('kundan_mishra', 'KUNDAN MISHRA'),
        ('anjali_yadav', 'ANJALI YADAV'),
        ('sakshi_manohare', 'SAKSHI MANOHARE'),
        ('divya_patel', 'DIVYA PATEL'),
        ('sandeep_kaur', 'SANDEEP KAUR'),
        ('muskan_tupkar', 'MUSKAN TUPKAR'),
        ('vaishali_mange', 'VAISHALI MANGE'),
        ('rinky_tiwari', 'RINKY TIWARI'),
        ('navneet_singh', 'NAVNEET SINGH'),
        ('rohan_prasad', 'ROHAN PRASAD'),
    ], string='Booking Executive', tracking=True)
    guest_names = fields.Text(string='Name of Guest(s)')
    num_adults = fields.Integer(string='Number of Guest(s)', compute='_compute_num_adults', store=True, readonly=False)
    employee_code = fields.Char(string='Employee Code', compute='_compute_employee_code', store=True, readonly=False)
    billing_company_id = fields.Many2one('res.partner', string='Billing Company', tracking=True,
                                        domain=[('is_company', '=', True)],
                                        compute='_compute_billing_company', store=True, readonly=False)
    document_number = fields.Char(string='Doc. no./Req. by')
    location = fields.Many2one('travel.hotel.city', string='Location')
    location_type = fields.Selection([
        ('domestic', 'Domestic'),
        ('international', 'International'),
    ], string='Location Type')
    checkin_date = fields.Date(string='Check-in Date', required=True, tracking=True)
    checkout_date = fields.Date(string='Check-out Date', required=True, tracking=True)
    num_nights = fields.Integer(string='Number of Nights', compute='_compute_num_nights', store=True)
    hotel_name = fields.Char(string='Hotel Name', required=True)
    total_amount = fields.Float(string='Total Amount', tracking=True)
    service_charge = fields.Float(string='Service Charge', compute='_compute_service_charge',
                                  store=True, readonly=False, tracking=True)
    mode_of_payment = fields.Selection([
        ('air_asia', 'Air Asia (India) Limited'),
        ('akasa_airline', 'Akasa Airline'),
        ('akbar_offshore', 'AKBAR OFFSHORE PVT LTD'),
        ('akbar_new', 'Akbar Online Booking Company Pvt Ltd - New'),
        ('akbar_old', 'Akbar Online Booking Company Pvt Ltd - Old'),
        ('aman_travels', 'Aman Travels Ltd'),
        ('interglobe', 'Interglobe Aviation Limited'),
        ('mmt_wallet', 'MMT Wallet'),
        ('pcc_akbar_offshore', 'PCC AKBAR OFFSHORE PVT LTD'),
        ('plus_wallet', 'Plus Wallet'),
        ('riya_offline', 'Riya Travels & Tours - Offline'),
        ('riya_online', 'Riya Travel & Tours - Online'),
        ('spicejet', 'Spicejet Limited'),
        ('axis_cc_vistara_deep_1236', 'Axis CC Vistara Deep Thakkar - 1236'),
        ('axis_debit_deep_2100', 'Axis Debit Deep - 2100 / Card - 5434'),
        ('hdfc_cc_deep_0943', 'HDFC CC Deep Thakkar-0943'),
        ('hdfc_cc_deep_6223', 'HDFC CC Deep Thakkar-6223'),
        ('ketan_axis_cc_ace_7929', 'Ketan Thakkar Axis CC Ace -7929/0735'),
        ('axis_cc_nirav_2281', 'Axis CC Nirav Thakkar-2281-7179/9743'),
        ('axis_debit_nirav_2448', 'AXIS Debit Nirav Thakkar -2448/5349/8819/7578'),
        ('hdfc_cc_nirav_9912', 'HDFC CC Nirav-9912 / 5100'),
        ('hdfc_nirav_cc_1583', 'HDFC NIRAV CC - 1583'),
        ('hdfc_nirav_cc_7122', 'HDFC Nirav CC-7122'),
        ('hdfc_earth_cc_3026', 'HDFC EARTH CC-3026'),
        ('hdfc_earth_cc_7209', 'HDFC The Earth CC - 7209/6804'),
        ('hdfc_earth_card_0481', 'HDFC The Earth Travel Card - 0481'),
        ('earth_hdfc_cc_1554', 'The Earth HDFC CC- 1554'),
        ('icici_deep_cc_0003', 'ICICI DEEP CC-0003'),
        ('icici_ketan_cc_9005', 'ICICI Ketan CC-9005'),
    ], string='Mode of Payment')
    booking_service_provider = fields.Selection([
        ('aman_travels', 'Aman Travels Ltd (GRN)'),
        ('makemytrip', 'MAKEMYTRIP'),
        ('treebo', 'TREEBO'),
        ('goibibo', 'GOIBIBO'),
        ('airbnb', 'AIRBNB'),
        ('meril_travel_desk', 'Meril Travel Desk'),
        ('travel_plus', 'Travel Plus'),
        ('other', 'Other'),
    ], string='Booking Service Provider')
    remark = fields.Selection([
        ('corporate', 'CORPORATE'),
        ('retail', 'RETAIL'),
        ('same_day_checking', 'SAME DAY CHECKING(IF NOT MAPPED)'),
        ('not_available', 'CORPORATE HOTEL NOT AVAILABLE AT LOCATION'),
        ('pax_not_agreed', 'PAX NOT AGREED FOR CORPORATE'),
        ('sold_out', 'CORPORATE SOLD OUT'),
        ('not_in_budget', 'CORPORATE HOTEL NOT IN BUDGET'),
        ('rate_expired', 'Contracted rate expired'),
        ('other', 'Other'),
    ], string='Remarks')
    confirmed_by = fields.Many2one('res.users', string='Confirmed By', tracking=True)

    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done'),
        ('cancelled', 'Cancelled'),
    ], string='Status', default='draft', tracking=True)
    cancellation_id = fields.Many2one('travel.booking.cancellation', string='Cancellation', readonly=True)

    @api.depends('total_amount')
    def _compute_service_charge(self):
        for rec in self:
            rec.service_charge = self.env['travel.service.charge'].get_service_charge(
                'hotel', booking_amount=rec.total_amount)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('travel.hotel.booking') or _('New')
        return super().create(vals_list)

    @api.depends('guest_names')
    def _compute_num_adults(self):
        for rec in self:
            if rec.guest_names:
                rec.num_adults = len([line for line in rec.guest_names.strip().splitlines() if line.strip()])
            else:
                rec.num_adults = 0

    @api.depends('checkin_date', 'checkout_date')
    def _compute_num_nights(self):
        for rec in self:
            if rec.checkin_date and rec.checkout_date and rec.checkout_date > rec.checkin_date:
                rec.num_nights = (rec.checkout_date - rec.checkin_date).days
            else:
                rec.num_nights = 0

    @api.constrains('checkin_date', 'checkout_date')
    def _check_dates(self):
        for rec in self:
            if rec.checkin_date and rec.checkout_date and rec.checkin_date >= rec.checkout_date:
                raise ValidationError(_('Check-out date must be after check-in date.'))

    def action_confirm(self):
        self.write({'state': 'confirmed'})
        self._generate_sale_purchase_orders()

    def _get_booking_type_label(self):
        return 'Hotel'

    def action_done(self):
        self.write({'state': 'done'})

    def action_cancel(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Cancel Booking'),
            'res_model': 'travel.booking.cancellation',
            'view_mode': 'form',
            'target': 'current',
            'context': {
                'default_booking_type': 'hotel',
                'default_hotel_booking_id': self.id,
                'default_partner_id': self.billing_company_id.id,
                'default_booking_ref': self.name,
                'default_booking_amount': self.total_amount,
            },
        }

    def action_draft(self):
        self.write({'state': 'draft'})

    @api.depends('guest_names')
    def _compute_employee_code(self):
        for rec in self:
            if rec.guest_names:
                names = [n.strip() for n in rec.guest_names.strip().splitlines() if n.strip()]
                codes = []
                for name in names:
                    records = self.env['travel.employee.code'].search([
                        ('employee_name', 'ilike', self._strip_name_prefix(name)),
                    ], limit=1)
                    if records:
                        codes.append(records[0].employee_code)
                rec.employee_code = ', '.join(codes) if codes else False
            else:
                rec.employee_code = False

    @api.depends('guest_names')
    def _compute_billing_company(self):
        for rec in self:
            if rec.guest_names:
                name = rec.guest_names.strip().splitlines()[0].strip() if rec.guest_names.strip() else False
                if name:
                    emp = self.env['travel.employee.code'].search([
                        ('employee_name', 'ilike', self._strip_name_prefix(name)),
                    ], limit=1)
                    if emp:
                        entity = emp.entity
                        partner = self.env['res.partner'].search([
                            ('name', 'ilike', entity),
                            ('is_company', '=', True),
                        ], limit=1)
                        if not partner:
                            core = entity
                            for suffix in ['Private Limited', 'Pvt Ltd', 'Pvt. Ltd.', 'Pvt Ltd.', 'Ltd', 'Ltd.']:
                                core = core.replace(suffix, '').strip().rstrip(',').strip()
                            if core:
                                partner = self.env['res.partner'].search([
                                    ('name', 'ilike', core),
                                    ('is_company', '=', True),
                                ], limit=1)
                        if partner:
                            rec.billing_company_id = partner.id
                            continue
            rec.billing_company_id = rec.billing_company_id
