# -*- coding: utf-8 -*-
import re
from odoo import models, fields, api, _


class HotelCancellation(models.Model):
    _name = 'travel.hotel.cancellation'
    _description = 'Hotel Cancellation'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc'

    name = fields.Char(string='Cancellation Reference', required=True, copy=False,
                       readonly=True, default=lambda self: _('New'))
    cancellation_date = fields.Date(string='Cancellation Date', default=fields.Date.context_today,
                                    required=True, tracking=True)
    booking_executive = fields.Many2one('res.users', string='Booking Executive',
                                        default=lambda self: self.env.user, tracking=True)
    guest_names = fields.Text(string='Name of Guest(s)')
    num_cancelled_guests = fields.Integer(string='Number of Guest(s) to be cancelled',
                                          compute='_compute_num_guests', store=True, readonly=False)
    employee_code = fields.Char(string='Employee Code', compute='_compute_from_guest',
                                store=True, readonly=False)
    billing_company_id = fields.Many2one('res.partner', string='Billing Company', tracking=True,
                                         domain=[('is_company', '=', True)],
                                         compute='_compute_from_guest', store=True, readonly=False)
    document_number = fields.Char(string='Doc. no./Req. by')
    location = fields.Many2one('travel.hotel.city', string='Location')
    num_nights_cancelled = fields.Integer(string='No. of night(s) to be cancelled')
    checkin_date = fields.Date(string='Check-in Date', tracking=True)
    checkout_date = fields.Date(string='Check-out Date', tracking=True)
    hotel_name = fields.Char(string='Hotel Name')
    booking_reference = fields.Char(string='Booking Reference Number')
    hotel_booking_id = fields.Many2one('travel.hotel.booking', string='Hotel Booking',
                                        domain=[('state', 'in', ('confirmed', 'done'))])
    total_amount = fields.Float(string='Total Amount', tracking=True)
    refund_amount = fields.Float(string='Refund Amount', tracking=True)
    mode_of_refund = fields.Selection([
        ('air_asia', 'Air Asia (India) Limited'),
        ('akasa_airline', 'Akasa Airline'),
        ('akbar_offshore', 'AKBAR OFFSHORE PVT LTD'),
        ('akbar_new', 'Akbar Online Booking Company Pvt Ltd - New'),
        ('akbar_old', 'Akbar Online Booking Company Pvt Ltd - Old'),
        ('aman_travels', 'Aman Travels Ltd'),
        ('interglobe', 'Interglobe Aviation Limited'),
        ('mmt_wallet', 'MMT Wallet'),
        ('pcc_akbar_offshore', 'PCC AKBAR OFFSHORE PVT LTD'),
        ('plus_wallet', 'Plus Wallet'),
        ('riya_offline', 'Riya Travels & Tours - Offline'),
        ('riya_online', 'Riya Travel & Tours - Online'),
        ('spicejet', 'Spicejet Limited'),
        ('axis_cc_vistara_deep_1236', 'Axis CC Vistara Deep Thakkar - 1236'),
        ('axis_debit_deep_2100', 'Axis Debit Deep - 2100 / Card - 5434'),
        ('hdfc_cc_deep_0943', 'HDFC CC Deep Thakkar-0943'),
        ('hdfc_cc_deep_6223', 'HDFC CC Deep Thakkar-6223'),
        ('ketan_axis_cc_ace_7929', 'Ketan Thakkar Axis CC Ace -7929/0735'),
        ('axis_cc_nirav_2281', 'Axis CC Nirav Thakkar-2281-7179/9743'),
        ('axis_debit_nirav_2448', 'AXIS Debit Nirav Thakkar -2448/5349/8819/7578'),
        ('hdfc_cc_nirav_9912', 'HDFC CC Nirav-9912 / 5100'),
        ('hdfc_nirav_cc_1583', 'HDFC NIRAV CC - 1583'),
        ('hdfc_nirav_cc_7122', 'HDFC Nirav CC-7122'),
        ('hdfc_earth_cc_3026', 'HDFC EARTH CC-3026'),
        ('hdfc_earth_cc_7209', 'HDFC The Earth CC - 7209/6804'),
        ('hdfc_earth_card_0481', 'HDFC The Earth Travel Card - 0481'),
        ('earth_hdfc_cc_1554', 'The Earth HDFC CC- 1554'),
        ('icici_deep_cc_0003', 'ICICI DEEP CC-0003'),
        ('icici_ketan_cc_9005', 'ICICI Ketan CC-9005'),
    ], string='Mode of Refund')
    remarks = fields.Text(string='Remarks')
    confirmed_by = fields.Many2one('res.users', string='Confirmed By', tracking=True)

    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('refunded', 'Refunded'),
        ('rejected', 'Rejected'),
    ], string='Status', default='draft', tracking=True)

    @api.depends('guest_names')
    def _compute_num_guests(self):
        for rec in self:
            if rec.guest_names:
                rec.num_cancelled_guests = len([l for l in rec.guest_names.strip().splitlines() if l.strip()])
            else:
                rec.num_cancelled_guests = 0

    @api.depends('guest_names')
    def _compute_from_guest(self):
        for rec in self:
            if rec.guest_names:
                names = [n.strip() for n in rec.guest_names.strip().splitlines() if n.strip()]
                codes = []
                first_emp = None
                for name in names:
                    clean_name = re.sub(r'^(MR\s+|MRS\s+|MS\s+|DR\s+)', '', name.strip(), flags=re.IGNORECASE).strip()
                    emp = self.env['travel.employee.code'].search([
                        ('employee_name', 'ilike', clean_name),
                    ], limit=1)
                    if emp:
                        codes.append(emp.employee_code)
                        if not first_emp:
                            first_emp = emp
                rec.employee_code = ', '.join(codes) if codes else False
                if first_emp:
                    entity = first_emp.entity
                    partner = self.env['res.partner'].search([
                        ('name', 'ilike', entity),
                        ('is_company', '=', True),
                    ], limit=1)
                    if not partner:
                        core = entity
                        for suffix in ['Private Limited', 'Pvt Ltd', 'Pvt. Ltd.', 'Pvt Ltd.', 'Ltd', 'Ltd.']:
                            core = core.replace(suffix, '').strip().rstrip(',').strip()
                        if core:
                            partner = self.env['res.partner'].search([
                                ('name', 'ilike', core),
                                ('is_company', '=', True),
                            ], limit=1)
                    rec.billing_company_id = partner.id if partner else rec.billing_company_id
                else:
                    rec.billing_company_id = rec.billing_company_id
            else:
                rec.employee_code = False
                rec.billing_company_id = rec.billing_company_id

    @api.onchange('hotel_booking_id')
    def _onchange_hotel_booking(self):
        if self.hotel_booking_id:
            booking = self.hotel_booking_id
            self.booking_reference = booking.name
            self.guest_names = booking.guest_names
            self.billing_company_id = booking.billing_company_id
            self.location = booking.location
            self.checkin_date = booking.checkin_date
            self.checkout_date = booking.checkout_date
            self.hotel_name = booking.hotel_name
            self.total_amount = booking.total_amount
            self.document_number = booking.document_number

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                from .sale_purchase_mixin import get_cancellation_ref
                vals['name'] = get_cancellation_ref(self.env, 'hotel') or self.env['ir.sequence'].next_by_code('travel.hotel.cancellation') or _('New')
        return super().create(vals_list)

    def action_confirm(self):
        self.write({'state': 'confirmed'})

    def action_refund(self):
        self.write({'state': 'refunded'})

    def action_reject(self):
        self.write({'state': 'rejected'})

    def action_draft(self):
        self.write({'state': 'draft'})
